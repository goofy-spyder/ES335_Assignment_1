import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, confusion_matrix, classification_report
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from tsfel import get_features_by_domain, time_series_features_extractor

# -----------------------------
# Load Raw Accelerometer Dataset
# -----------------------------
X_train = np.load("Dataset/X_train.npy")   # shape (n_samples, 500, 3)
y_train = np.load("Dataset/y_train.npy")
X_test = np.load("Dataset/X_test.npy")
y_test = np.load("Dataset/y_test.npy")

# Flatten raw timeseries into features for DecisionTree
X_train_raw = X_train.reshape(X_train.shape[0], -1)
X_test_raw = X_test.reshape(X_test.shape[0], -1)

print("Raw accelerometer feature shape:", X_train_raw.shape)

# -----------------------------
# TSFEL Features
# -----------------------------
cfg = get_features_by_domain()
# Extract features (this may take a bit of time)
X_train_tsfel = time_series_features_extractor(cfg, X_train[:, :, 0], fs=50).values
X_test_tsfel = time_series_features_extractor(cfg, X_test[:, :, 0], fs=50).values

scaler = StandardScaler()
X_train_tsfel = scaler.fit_transform(X_train_tsfel)
X_test_tsfel = scaler.transform(X_test_tsfel)

print("TSFEL feature shape:", X_train_tsfel.shape)

# -----------------------------
# Built-in UCI-HAR Features (561 features)
# -----------------------------
X_train_feat = pd.read_csv("UCI HAR Dataset/train/X_train.txt", delim_whitespace=True, header=None)
y_train_feat = pd.read_csv("UCI HAR Dataset/train/y_train.txt", header=None).values.ravel()
X_test_feat = pd.read_csv("UCI HAR Dataset/test/X_test.txt", delim_whitespace=True, header=None)
y_test_feat = pd.read_csv("UCI HAR Dataset/test/y_test.txt", header=None).values.ravel()

scaler = StandardScaler()
X_train_feat = scaler.fit_transform(X_train_feat)
X_test_feat = scaler.transform(X_test_feat)

print("UCI-HAR built-in feature shape:", X_train_feat.shape)

# -----------------------------
# Train & Evaluate Function
# -----------------------------
def evaluate_model(X_train, y_train, X_test, y_test, label="Model"):
    clf = DecisionTreeClassifier(random_state=42)
    clf.fit(X_train, y_train)
    y_pred = clf.predict(X_test)

    acc = accuracy_score(y_test, y_pred)
    prec = precision_score(y_test, y_pred, average="weighted")
    rec = recall_score(y_test, y_pred, average="weighted")
    cm = confusion_matrix(y_test, y_pred)

    print(f"\n=== {label} ===")
    print("Accuracy:", acc)
    print("Precision:", prec)
    print("Recall:", rec)
    print("Confusion Matrix:\n", cm)
    return acc, prec, rec, cm

# Evaluate all three
acc_raw, prec_raw, rec_raw, cm_raw = evaluate_model(X_train_raw, y_train, X_test_raw, y_test, "Raw Accelerometer Data")
acc_tsfel, prec_tsfel, rec_tsfel, cm_tsfel = evaluate_model(X_train_tsfel, y_train, X_test_tsfel, y_test, "TSFEL Features")
acc_feat, prec_feat, rec_feat, cm_feat = evaluate_model(X_train_feat, y_train_feat, X_test_feat, y_test_feat, "UCI-HAR Built-in Features")

# -----------------------------
# Decision Tree Depth Variation
# -----------------------------
depths = range(2, 9)
acc_raw_list, acc_tsfel_list, acc_feat_list = [], [], []

for d in depths:
    clf = DecisionTreeClassifier(max_depth=d, random_state=42)
    
    clf.fit(X_train_raw, y_train)
    acc_raw_list.append(accuracy_score(y_test, clf.predict(X_test_raw)))

    clf.fit(X_train_tsfel, y_train)
    acc_tsfel_list.append(accuracy_score(y_test, clf.predict(X_test_tsfel)))

    clf.fit(X_train_feat, y_train_feat)
    acc_feat_list.append(accuracy_score(y_test_feat, clf.predict(X_test_feat)))

plt.figure(figsize=(8,6))
plt.plot(depths, acc_raw_list, '-o', label="Raw Data")
plt.plot(depths, acc_tsfel_list, '-o', label="TSFEL Features")
plt.plot(depths, acc_feat_list, '-o', label="Built-in Features")
plt.xlabel("Decision Tree Depth")
plt.ylabel("Test Accuracy")
plt.title("Decision Tree Performance vs Depth")
plt.legend()
plt.grid(True)
plt.show()

# -----------------------------
# Observations Placeholder
# -----------------------------
print("\n=== Observations ===")
print("1. Raw accelerometer data often struggles because tree splits on thousands of time points → overfitting.")
print("2. TSFEL features give more interpretable and compact representation, better generalization.")
print("3. Built-in UCI-HAR features (561) usually perform best since they capture both time and frequency domain info.")
print("4. Model might perform badly on participants with unusual motion style (e.g., walking differently) or on activities like 'Walking Upstairs vs Walking Downstairs' since signals overlap.")
